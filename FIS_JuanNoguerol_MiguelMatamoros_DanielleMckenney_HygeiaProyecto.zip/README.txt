Se entrega:
-Documentación del microservicio
-Informes de Clockify
-Presentación pdf
-Videos de demostración

Otras fuentes:

Prototipos FIGMA V1:
https://www.figma.com/file/I0TnX27PccZ9qsoA1PoQVA/Hygeia?type=design&node-id=0-1&mode=design

Repositorio microservicio:
https://github.com/hygeia-care/hygeia-care-devices
