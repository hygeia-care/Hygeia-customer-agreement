Se entrega:
-Documento por pareja (Se ha incluido en el repositorio del microservicio users)
-Informes de Clockify
-Presentación ppt
-Video de demostración

Otras fuentes:

Prototipos FIGMA V1:
https://www.figma.com/file/I0TnX27PccZ9qsoA1PoQVA/Hygeia?type=design&node-id=0-1&mode=design

Repositorio microservicio:
https://github.com/hygeia-care/hygeia-care-users

